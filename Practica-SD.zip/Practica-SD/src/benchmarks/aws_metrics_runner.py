"""AWS/RabbitMQ benchmark runner with automatic report and plot generation.

This runner is meant to be executed from a client EC2 instance. It runs one
benchmark point, samples RabbitMQ backlog while the workload is running, appends
the result to a labelled series, and regenerates the plots required by the
assignment.
"""
import argparse
import json
import os
import sys
import threading
import time
from datetime import datetime
from typing import Dict, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.benchmarks.parser import BenchmarkParser
from src.common.config import RABBITMQ_HOST, RABBITMQ_PASSWORD, RABBITMQ_USER
from src.common.logger import get_logger
from src.indirect.client import RabbitMQBenchmarkRunner

try:
    mpl_config_dir = os.path.join(os.getcwd(), ".matplotlib")
    os.makedirs(mpl_config_dir, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", mpl_config_dir)

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

try:
    import requests

    REQUESTS_AVAILABLE = True 
except ImportError:
    REQUESTS_AVAILABLE = False


logger = get_logger(__name__)


class QueueBacklogSampler:
    """Sample RabbitMQ queue depth through the management HTTP API."""

    def __init__(
        self,
        api_base_url: str,
        queue_name: str,
        username: str,
        password: str,
        interval: float,
    ):
        self.api_base_url = api_base_url.rstrip("/")
        self.queue_name = queue_name
        self.username = username
        self.password = password
        self.interval = max(0.2, interval)
        self.samples: List[Dict] = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._started_at = None

    def start(self):
        if not REQUESTS_AVAILABLE:
            logger.warning("requests is not available; backlog sampling disabled")
            return
        self._started_at = time.time()
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=self.interval + 2)

    def _run(self):
        encoded_vhost = "%2f"
        url = f"{self.api_base_url}/api/queues/{encoded_vhost}/{self.queue_name}"

        while not self._stop.is_set():
            now = time.time()
            sample = {
                "timestamp": now,
                "elapsed": now - self._started_at if self._started_at else 0.0,
                "messages": 0,
                "messages_ready": 0,
                "messages_unacknowledged": 0,
                "error": None,
            }

            try:
                response = requests.get(
                    url,
                    auth=(self.username, self.password),
                    timeout=2,
                )
                if response.status_code == 200:
                    payload = response.json()
                    sample["messages"] = int(payload.get("messages", 0))
                    sample["messages_ready"] = int(payload.get("messages_ready", 0))
                    sample["messages_unacknowledged"] = int(
                        payload.get("messages_unacknowledged", 0)
                    )
                else:
                    sample["error"] = f"HTTP {response.status_code}"
            except Exception as exc:
                sample["error"] = str(exc)

            self.samples.append(sample)
            self._stop.wait(self.interval)


def _safe_label(label: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in label.strip())


def _load_series(path: str) -> Dict:
    if not os.path.exists(path):
        return {"runs": []}
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _save_json(path: str, payload: Dict):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def _write_summary(path: str, series: Dict):
    lines = []
    lines.append("=" * 80)
    lines.append("AWS RABBITMQ BENCHMARK SUMMARY")
    lines.append(f"Generated at: {datetime.now().isoformat()}")
    lines.append("=" * 80)

    for run in sorted(series["runs"], key=lambda item: (item["ticket_type"], item["backend_count"])):
        metrics = run["metrics"]
        type_stats = metrics.get("by_type", {}).get(run["ticket_type"], {}) or {}
        backlog = run.get("backlog", {})
        lines.append("")
        lines.append(
            f"{run['ticket_type'].upper()} | backend_workers={run['backend_count']} | "
            f"client_workers={run['client_workers']} | in_flight={run['in_flight']}"
        )
        lines.append(f"  benchmark: {run['benchmark_file']}")
        lines.append(f"  total_time: {metrics.get('total_time', 0):.3f}s")
        lines.append(f"  total_operations: {metrics.get('total_operations', 0)}")
        lines.append(f"  throughput: {metrics.get('throughput', 0):.3f} ops/s")
        lines.append(f"  success_rate: {metrics.get('success_rate', 0):.2f}%")
        lines.append(f"  avg_latency: {type_stats.get('avg_latency', 0):.4f}s")
        lines.append(f"  p50_latency: {type_stats.get('p50_latency', 0):.4f}s")
        lines.append(f"  p95_latency: {type_stats.get('p95_latency', 0):.4f}s")
        lines.append(f"  p99_latency: {type_stats.get('p99_latency', 0):.4f}s")
        lines.append(f"  max_backlog: {backlog.get('max_messages', 0)} messages")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))


def _plot_throughput_vs_workers(series: Dict, output_dir: str, label: str) -> List[str]:
    paths = []
    grouped: Dict[str, List[Dict]] = {}
    for run in series["runs"]:
        grouped.setdefault(run["ticket_type"], []).append(run)

    for ticket_type, runs in grouped.items():
        runs = sorted(runs, key=lambda item: item["backend_count"])
        if not runs:
            continue

        x_values = [run["backend_count"] for run in runs]
        y_values = [run["metrics"].get("throughput", 0) for run in runs]

        plt.figure(figsize=(8, 5))
        plt.plot(x_values, y_values, marker="o", linewidth=2)
        plt.xlabel("Backend workers")
        plt.ylabel("Throughput (completed ops/sec)")
        plt.title(f"Throughput vs workers - {ticket_type}")
        plt.grid(True, alpha=0.3)
        path = os.path.join(output_dir, f"aws_throughput_vs_workers_{ticket_type}_{label}.png")
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.close()
        paths.append(path)

    return paths


def _plot_latency_percentiles(series: Dict, output_dir: str, label: str) -> List[str]:
    paths = []
    grouped: Dict[str, List[Dict]] = {}
    for run in series["runs"]:
        grouped.setdefault(run["ticket_type"], []).append(run)

    for ticket_type, runs in grouped.items():
        runs = sorted(runs, key=lambda item: item["backend_count"])
        x_values = [run["backend_count"] for run in runs]
        p50 = []
        p95 = []
        p99 = []
        for run in runs:
            stats = run["metrics"].get("by_type", {}).get(ticket_type, {}) or {}
            p50.append(stats.get("p50_latency", 0))
            p95.append(stats.get("p95_latency", 0))
            p99.append(stats.get("p99_latency", 0))

        plt.figure(figsize=(8, 5))
        plt.plot(x_values, p50, marker="o", linewidth=2, label="p50")
        plt.plot(x_values, p95, marker="s", linewidth=2, label="p95")
        plt.plot(x_values, p99, marker="^", linewidth=2, label="p99")
        plt.xlabel("Backend workers")
        plt.ylabel("Latency (seconds)")
        plt.title(f"Latency percentiles - {ticket_type}")
        plt.legend()
        plt.grid(True, alpha=0.3)
        path = os.path.join(output_dir, f"aws_latency_percentiles_{ticket_type}_{label}.png")
        plt.savefig(path, dpi=150, bbox_inches="tight")
        plt.close()
        paths.append(path)

    return paths


def _plot_backlog_for_run(run: Dict, output_dir: str, label: str) -> str:
    samples = run.get("backlog_samples", [])
    if not samples:
        return ""

    x_values = [sample["elapsed"] for sample in samples]
    messages = [sample["messages"] for sample in samples]
    ready = [sample["messages_ready"] for sample in samples]
    unacked = [sample["messages_unacknowledged"] for sample in samples]

    plt.figure(figsize=(9, 5))
    plt.plot(x_values, messages, linewidth=2, label="total")
    plt.plot(x_values, ready, linewidth=2, label="ready")
    plt.plot(x_values, unacked, linewidth=2, label="unacknowledged")
    plt.xlabel("Time since benchmark start (seconds)")
    plt.ylabel("Queue messages")
    plt.title(
        f"RabbitMQ backlog - {run['ticket_type']} - "
        f"{run['backend_count']} backend workers"
    )
    plt.legend()
    plt.grid(True, alpha=0.3)
    path = os.path.join(
        output_dir,
        f"aws_backlog_{run['ticket_type']}_w{run['backend_count']}_{label}.png",
    )
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    return path


def _generate_plots(series: Dict, output_dir: str, label: str) -> List[str]:
    if not MATPLOTLIB_AVAILABLE:
        logger.warning("matplotlib is not available; plots skipped")
        return []

    os.makedirs(output_dir, exist_ok=True)
    paths = []
    paths.extend(_plot_throughput_vs_workers(series, output_dir, label))
    paths.extend(_plot_latency_percentiles(series, output_dir, label))

    latest_run = series["runs"][-1] if series["runs"] else None
    if latest_run:
        backlog_path = _plot_backlog_for_run(latest_run, output_dir, label)
        if backlog_path:
            paths.append(backlog_path)

    return paths


def _summarize_backlog(samples: List[Dict]) -> Dict:
    valid = [sample for sample in samples if not sample.get("error")]
    if not valid:
        return {
            "sample_count": len(samples),
            "max_messages": 0,
            "max_messages_ready": 0,
            "max_messages_unacknowledged": 0,
        }

    return {
        "sample_count": len(samples),
        "max_messages": max(sample["messages"] for sample in valid),
        "max_messages_ready": max(sample["messages_ready"] for sample in valid),
        "max_messages_unacknowledged": max(
            sample["messages_unacknowledged"] for sample in valid
        ),
    }


def main():
    parser = argparse.ArgumentParser(
        description="Run AWS RabbitMQ benchmark and regenerate report plots",
    )
    parser.add_argument("benchmark_file", help="Benchmark file to execute")
    parser.add_argument("--ticket-type", choices=["unnumbered", "numbered"], required=True)
    parser.add_argument(
        "--backend-count",
        type=int,
        required=True,
        help="Number of active backend workers for this run",
    )
    parser.add_argument("--client-workers", type=int, default=4)
    parser.add_argument("--in-flight", type=int, default=100)
    parser.add_argument("--label", default="aws_rabbitmq")
    parser.add_argument(
        "--rabbitmq-api",
        default=f"http://{RABBITMQ_HOST}:15672",
        help="RabbitMQ management API base URL",
    )
    parser.add_argument("--rabbitmq-user", default=RABBITMQ_USER)
    parser.add_argument("--rabbitmq-password", default=RABBITMQ_PASSWORD)
    parser.add_argument("--queue", default="ticket_requests")
    parser.add_argument("--sample-interval", type=float, default=1.0)
    parser.add_argument("--no-reset", action="store_true")
    args = parser.parse_args()

    safe_label = _safe_label(args.label) or "aws_rabbitmq"
    reports_dir = os.path.join("results", "reports")
    plots_dir = os.path.join("results", "plots")
    series_path = os.path.join(reports_dir, f"aws_metrics_{safe_label}.json")
    summary_path = os.path.join(reports_dir, f"aws_metrics_{safe_label}.txt")

    parsed = BenchmarkParser(args.benchmark_file)
    operations = parsed.parse()
    if not operations:
        logger.error("Benchmark file contains no valid operations: %s", args.benchmark_file)
        return 1

    sampler = QueueBacklogSampler(
        api_base_url=args.rabbitmq_api,
        queue_name=args.queue,
        username=args.rabbitmq_user,
        password=args.rabbitmq_password,
        interval=args.sample_interval,
    )

    sampler.start()
    runner = RabbitMQBenchmarkRunner(
        num_workers=args.client_workers,
        max_in_flight=args.in_flight,
        reset_state=not args.no_reset,
    )
    metrics = runner.run_benchmark(args.benchmark_file).to_dict()
    sampler.stop()

    run = {
        "timestamp": datetime.now().isoformat(),
        "architecture": "rabbitmq",
        "ticket_type": args.ticket_type,
        "benchmark_file": args.benchmark_file,
        "backend_count": args.backend_count,
        "client_workers": args.client_workers,
        "in_flight": args.in_flight,
        "rabbitmq_api": args.rabbitmq_api,
        "metrics": metrics,
        "backlog": _summarize_backlog(sampler.samples),
        "backlog_samples": sampler.samples,
    }

    series = _load_series(series_path)
    series["runs"] = [
        existing
        for existing in series.get("runs", [])
        if not (
            existing.get("ticket_type") == args.ticket_type
            and existing.get("backend_count") == args.backend_count
            and existing.get("benchmark_file") == args.benchmark_file
        )
    ]
    series["runs"].append(run)
    _save_json(series_path, series)
    _write_summary(summary_path, series)
    plot_paths = _generate_plots(series, plots_dir, safe_label)

    logger.info("Saved metrics JSON: %s", series_path)
    logger.info("Saved summary: %s", summary_path)
    logger.info("Generated plots: %s", plot_paths)
    return 0


if __name__ == "__main__":
    sys.exit(main())
